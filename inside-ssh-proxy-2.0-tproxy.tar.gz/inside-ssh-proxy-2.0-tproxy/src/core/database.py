"""Database configuration and models."""
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Boolean, ForeignKey, Text, CheckConstraint, or_, BigInteger, Time
from sqlalchemy.dialects import postgresql
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import os
from dotenv import load_dotenv

# Flask-Login support (optional - only needed for Tower web UI)
try:
    from flask_login import UserMixin
    FLASK_LOGIN_AVAILABLE = True
except ImportError:
    # Standalone mode without Flask - create dummy mixin
    FLASK_LOGIN_AVAILABLE = False
    class UserMixin:
        """Dummy UserMixin for standalone mode"""
        pass

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL")

# Only create engine if DATABASE_URL is set (all-in-one mode)
# In standalone/gate-only mode, this module won't be fully initialized
if DATABASE_URL:
    engine = create_engine(DATABASE_URL, connect_args={"options": "-c timezone=utc"})
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
else:
    engine = None
    SessionLocal = None

Base = declarative_base()


class User(UserMixin, Base):
    """User model - synchronized with FreeIPA."""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(255), unique=True, nullable=False, index=True)
    email = Column(String(255))
    full_name = Column(String(255))
    source_ip = Column(String(45), index=True)  # DEPRECATED: Use user_source_ips table instead
    is_active = Column(Boolean, default=True)
    port_forwarding_allowed = Column(Boolean, default=False, nullable=False)
    
    # Permission system: 0=SuperAdmin, 100=Admin, 500=Operator, 1000=User (no GUI)
    permission_level = Column(Integer, default=1000, nullable=False, index=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    access_grants = relationship("AccessGrant", back_populates="user")
    source_ips = relationship("UserSourceIP", back_populates="user", cascade="all, delete-orphan")
    access_policies = relationship("AccessPolicy", back_populates="user", cascade="all, delete-orphan", foreign_keys="[AccessPolicy.user_id]")
    policies_created = relationship("AccessPolicy", back_populates="created_by", foreign_keys="[AccessPolicy.created_by_user_id]")
    sessions = relationship("SessionRecording", back_populates="user")
    audit_logs = relationship("AuditLog", back_populates="user")



class Server(Base):
    """Target server model."""
    __tablename__ = "servers"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    ip_address = Column(String(45), nullable=False, index=True)  # IPv4/IPv6
    description = Column(Text)
    os_type = Column(String(50))  # linux, windows
    ssh_port = Column(Integer, default=22)
    rdp_port = Column(Integer, default=3389)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Maintenance mode
    in_maintenance = Column(Boolean, default=False, nullable=False)
    maintenance_scheduled_at = Column(DateTime)
    maintenance_reason = Column(Text)
    maintenance_grace_minutes = Column(Integer, default=15)
    
    # Soft delete (preserve history)
    deleted = Column(Boolean, default=False, nullable=False, index=True)
    deleted_at = Column(DateTime)
    deleted_by_user_id = Column(Integer, ForeignKey("users.id"))
    
    # Relationships
    access_grants = relationship("AccessGrant", back_populates="server")
    ip_allocations = relationship("IPAllocation", back_populates="server")
    group_memberships = relationship("ServerGroupMember", back_populates="server", cascade="all, delete-orphan")
    access_policies = relationship("AccessPolicy", back_populates="target_server")
    deleted_by = relationship("User", foreign_keys=[deleted_by_user_id])


class AccessGrant(Base):
    """User access grant with temporal permissions."""
    __tablename__ = "access_grants"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    server_id = Column(Integer, ForeignKey("servers.id"), nullable=False, index=True)
    protocol = Column(String(10), nullable=False)  # ssh, rdp
    start_time = Column(DateTime, nullable=False, default=datetime.utcnow)
    end_time = Column(DateTime, nullable=False)  # Temporal access
    is_active = Column(Boolean, default=True)
    granted_by = Column(String(255))
    reason = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="access_grants")
    server = relationship("Server", back_populates="access_grants")


class IPAllocation(Base):
    """IP pool allocation tracking - supports both permanent server assignments and temporary user sessions.
    
    IP pools are per-gate and can overlap between gates (same IP can be used on different gates).
    """
    __tablename__ = "ip_allocations"
    
    id = Column(Integer, primary_key=True, index=True)
    allocated_ip = Column(String(45), nullable=False, index=True)  # NOT globally unique - unique per gate
    server_id = Column(Integer, ForeignKey("servers.id"), nullable=False)
    gate_id = Column(Integer, ForeignKey("gates.id"), nullable=True)  # Which gate owns this IP allocation
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)  # NULL for permanent server assignments
    source_ip = Column(String(45), nullable=True)  # NULL for permanent assignments, filled for session-based
    allocated_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=True)  # NULL for permanent assignments
    is_active = Column(Boolean, default=True)
    session_id = Column(String(255), unique=True, nullable=True)  # NULL for permanent assignments
    
    # Relationships
    server = relationship("Server", back_populates="ip_allocations")
    gate = relationship("Gate", back_populates="ip_allocations")


class Gate(Base):
    """Gate (data plane) registration and tracking."""
    __tablename__ = "gates"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), unique=True, nullable=False, index=True)  # e.g., "gate-localhost", "gate-dmz", "gate-cloud"
    hostname = Column(String(255), nullable=False)  # FQDN or IP
    api_token = Column(String(255), nullable=False, unique=True)  # Bearer token for authentication
    location = Column(String(255))  # e.g., "Datacenter 1", "AWS us-east-1"
    description = Column(Text)
    
    # IP Pool Configuration (per-gate)
    ip_pool_network = Column(String(45), default="10.0.160.128/25")  # CIDR notation
    ip_pool_start = Column(String(45), default="10.0.160.129")  # First usable IP
    ip_pool_end = Column(String(45), default="10.0.160.254")  # Last usable IP
    
    # Status tracking
    status = Column(String(20), default="offline", nullable=False)  # "online", "offline", "error"
    last_heartbeat = Column(DateTime)
    version = Column(String(50))  # Gate software version
    
    # Metadata
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    # Maintenance mode
    in_maintenance = Column(Boolean, default=False, nullable=False)
    maintenance_scheduled_at = Column(DateTime)
    
    # MFA configuration - fingerprint-based session persistence
    mfa_enabled = Column(Boolean, default=False, nullable=False)  # If true, gate uses MFA for unknown IPs
    maintenance_reason = Column(Text)
    maintenance_grace_minutes = Column(Integer, default=15)
    
    # Auto-grant configuration (per-gate control)
    auto_grant_enabled = Column(Boolean, default=True, nullable=False)
    auto_grant_duration_days = Column(Integer, default=7, nullable=False)
    auto_grant_inactivity_timeout_minutes = Column(Integer, default=60, nullable=False)
    auto_grant_port_forwarding = Column(Boolean, default=True, nullable=False)
    
    # Custom messages for SSH banners and error messages
    msg_welcome_banner = Column(Text)  # Welcome message shown after successful auth
    msg_no_backend = Column(Text)  # When backend server not found in registry
    msg_no_person = Column(Text)  # When person/user not recognized
    msg_no_grant = Column(Text)  # When no active grant/policy for access
    msg_maintenance = Column(Text)  # When system is in maintenance mode
    msg_time_window = Column(Text)  # When outside allowed time window
    
    # Relationships
    session_recordings = relationship("SessionRecording", back_populates="gate")
    sessions = relationship("Session", back_populates="gate", foreign_keys="[Session.gate_id]")
    stays = relationship("Stay", back_populates="gate")
    ip_allocations = relationship("IPAllocation", back_populates="gate")


class SessionRecording(Base):
    """Session recording metadata."""
    __tablename__ = "session_recordings"
    
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String(255), unique=True, nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    server_id = Column(Integer, ForeignKey("servers.id"), nullable=False)
    gate_id = Column(Integer, ForeignKey("gates.id"), nullable=True)  # NEW: Which gate handled this session
    protocol = Column(String(10), nullable=False)  # ssh, rdp
    source_ip = Column(String(45), nullable=False)
    allocated_ip = Column(String(45), nullable=False)
    recording_path = Column(Text, nullable=False)
    start_time = Column(DateTime, nullable=False, default=datetime.utcnow)
    end_time = Column(DateTime)
    duration_seconds = Column(Integer)
    file_size_bytes = Column(Integer)
    
    # Relationships
    user = relationship("User", back_populates="sessions")
    gate = relationship("Gate", back_populates="session_recordings")


class AuditLog(Base):
    """Audit log for all actions."""
    __tablename__ = "audit_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True)
    action = Column(String(100), nullable=False, index=True)
    resource_type = Column(String(50))  # user, server, access_grant, etc.
    resource_id = Column(Integer)
    source_ip = Column(String(45))
    success = Column(Boolean, nullable=False)
    details = Column(Text)
    timestamp = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    
    # Relationships
    user = relationship("User", back_populates="audit_logs")


class MaintenanceAccess(Base):
    """Personnel with access during maintenance mode."""
    __tablename__ = "maintenance_access"
    
    id = Column(Integer, primary_key=True, index=True)
    entity_type = Column(String(10), nullable=False)  # 'gate' or 'server'
    entity_id = Column(Integer, nullable=False, index=True)
    person_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        CheckConstraint("entity_type IN ('gate', 'server')", name="check_entity_type"),
    )


class UserSourceIP(Base):
    """Multiple source IPs per user - for flexible access control."""
    __tablename__ = "user_source_ips"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    source_ip = Column(String(45), nullable=False, index=True)
    label = Column(String(255))  # e.g., "Home", "Office", "VPN"
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="source_ips")
    access_policies = relationship("AccessPolicy", back_populates="source_ip_ref")
    
    __table_args__ = (
        CheckConstraint("user_id IS NOT NULL", name="check_user_source_ip_user_id"),
    )


class ServerGroup(Base):
    """Server groups/tags for flexible access management."""
    __tablename__ = "server_groups"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), unique=True, nullable=False, index=True)
    description = Column(Text)
    parent_group_id = Column(Integer, ForeignKey("server_groups.id", ondelete="SET NULL"), index=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    parent_group = relationship("ServerGroup", remote_side=[id], backref="child_groups")
    members = relationship("ServerGroupMember", back_populates="group", cascade="all, delete-orphan")
    access_policies = relationship("AccessPolicy", back_populates="target_group")
    
    __table_args__ = (
        CheckConstraint("id != parent_group_id", name="server_groups_no_self_reference"),
    )


class ServerGroupMember(Base):
    """N:M relationship: servers can belong to multiple groups."""
    __tablename__ = "server_group_members"
    
    id = Column(Integer, primary_key=True, index=True)
    server_id = Column(Integer, ForeignKey("servers.id"), nullable=False, index=True)
    group_id = Column(Integer, ForeignKey("server_groups.id"), nullable=False, index=True)
    added_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    server = relationship("Server", back_populates="group_memberships")
    group = relationship("ServerGroup", back_populates="members")
    
    __table_args__ = (
        CheckConstraint("server_id IS NOT NULL AND group_id IS NOT NULL", name="check_group_member_ids"),
    )


class UserGroup(Base):
    """User groups for hierarchical access management with recursive parent support."""
    __tablename__ = "user_groups"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), unique=True, nullable=False, index=True)
    description = Column(Text)
    parent_group_id = Column(Integer, ForeignKey("user_groups.id", ondelete="SET NULL"), index=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    parent_group = relationship("UserGroup", remote_side=[id], backref="child_groups")
    members = relationship("UserGroupMember", back_populates="group", cascade="all, delete-orphan")
    access_policies = relationship("AccessPolicy", back_populates="user_group")
    
    __table_args__ = (
        CheckConstraint("id != parent_group_id", name="user_groups_no_self_reference"),
    )


class UserGroupMember(Base):
    """N:M relationship: users can belong to multiple groups."""
    __tablename__ = "user_group_members"
    
    id = Column(Integer, primary_key=True, index=True)
    user_group_id = Column(Integer, ForeignKey("user_groups.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    added_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    user = relationship("User", backref="group_memberships")
    group = relationship("UserGroup", back_populates="members")
    
    __table_args__ = (
        CheckConstraint("user_group_id IS NOT NULL AND user_id IS NOT NULL", name="check_user_group_member_ids"),
    )


class AccessPolicy(Base):
    """Flexible access policy with granular control (group/server/service level)."""
    __tablename__ = "access_policies"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    user_group_id = Column(Integer, ForeignKey("user_groups.id", ondelete="CASCADE"), nullable=True, index=True)
    
    # Source IP restriction (NULL = all user's IPs allowed)
    source_ip_id = Column(Integer, ForeignKey("user_source_ips.id"), index=True)
    
    # Scope: 'group' (all servers in group), 'server' (specific server), 'service' (server+protocol)
    scope_type = Column(String(20), nullable=False, index=True)
    
    # Target references (based on scope_type)
    target_group_id = Column(Integer, ForeignKey("server_groups.id"), index=True)
    target_server_id = Column(Integer, ForeignKey("servers.id"), index=True)
    
    # Protocol filter (NULL = all protocols, 'ssh', 'rdp')
    protocol = Column(String(10))
    
    # Port forwarding permission
    port_forwarding_allowed = Column(Boolean, default=False, nullable=False)
    
    # Temporal access
    start_time = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    end_time = Column(DateTime, nullable=True, index=True)  # NULL = permanent access
    
    # Inactivity timeout (minutes) - NULL or 0 = disabled, default 60 minutes
    inactivity_timeout_minutes = Column(Integer, nullable=True, default=60)
    
    # MFA requirement - if True, user must complete SAML authentication before access
    mfa_required = Column(Boolean, default=False, nullable=False)
    
    # Schedule-based access (recurring time windows)
    use_schedules = Column(Boolean, default=False, nullable=False)  # If True, check policy_schedules
    
    is_active = Column(Boolean, default=True, index=True)
    granted_by = Column(String(255))
    reason = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    created_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    
    # Relationships
    user = relationship("User", back_populates="access_policies", foreign_keys=[user_id])
    created_by = relationship("User", back_populates="policies_created", foreign_keys=[created_by_user_id])
    user_group = relationship("UserGroup", back_populates="access_policies")
    source_ip_ref = relationship("UserSourceIP", back_populates="access_policies")
    target_group = relationship("ServerGroup", back_populates="access_policies")
    target_server = relationship("Server", back_populates="access_policies")
    ssh_logins = relationship("PolicySSHLogin", back_populates="policy", cascade="all, delete-orphan")
    schedules = relationship("PolicySchedule", back_populates="policy", cascade="all, delete-orphan")
    
    __table_args__ = (
        CheckConstraint(
            "scope_type IN ('group', 'server', 'service')",
            name="check_scope_type_valid"
        ),
        CheckConstraint(
            "protocol IS NULL OR protocol IN ('ssh', 'rdp')",
            name="check_protocol_valid"
        ),
        CheckConstraint(
            "(scope_type = 'group' AND target_group_id IS NOT NULL AND target_server_id IS NULL) OR "
            "(scope_type IN ('server', 'service') AND target_server_id IS NOT NULL AND target_group_id IS NULL)",
            name="check_scope_targets"
        ),
        CheckConstraint(
            "(user_id IS NOT NULL AND user_group_id IS NULL) OR (user_id IS NULL AND user_group_id IS NOT NULL)",
            name="check_user_or_group"
        ),
    )


class PolicySSHLogin(Base):
    """SSH login restrictions for access policies. Empty = all logins allowed."""
    __tablename__ = "policy_ssh_logins"
    
    id = Column(Integer, primary_key=True, index=True)
    policy_id = Column(Integer, ForeignKey("access_policies.id", ondelete="CASCADE"), nullable=False, index=True)
    allowed_login = Column(String(255), nullable=False)
    
    # Relationships
    policy = relationship("AccessPolicy", back_populates="ssh_logins")
    
    __table_args__ = (
        CheckConstraint("policy_id IS NOT NULL", name="check_ssh_login_policy_id"),
    )


class PolicySchedule(Base):
    """Time-based schedule rules for access policies (recurring windows)."""
    __tablename__ = "policy_schedules"
    
    id = Column(Integer, primary_key=True, index=True)
    policy_id = Column(Integer, ForeignKey("access_policies.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(100))  # Human-readable name (e.g., "Business hours", "Weekend backup window")
    
    # Weekday filter: 0=Monday, 6=Sunday. NULL = all days
    weekdays = Column(postgresql.ARRAY(Integer))
    
    # Time range (NULL = all day)
    time_start = Column(Time)  # e.g., "08:00"
    time_end = Column(Time)    # e.g., "16:00"
    
    # Month filter: 1-12. NULL = all months
    months = Column(postgresql.ARRAY(Integer))
    
    # Day of month filter: 1-31. NULL = all days
    days_of_month = Column(postgresql.ARRAY(Integer))
    
    # Timezone for time comparison (default: Europe/Warsaw)
    timezone = Column(String(50), default='Europe/Warsaw', nullable=False)
    
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    policy = relationship("AccessPolicy", back_populates="schedules")


class PolicyAuditLog(Base):
    """Audit trail for all policy changes (full history, no deletion allowed)."""
    __tablename__ = "policy_audit_log"
    
    id = Column(Integer, primary_key=True, index=True)
    policy_id = Column(Integer, ForeignKey("access_policies.id", ondelete="CASCADE"), nullable=False, index=True)
    changed_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    
    # Change tracking
    change_type = Column(String(50), nullable=False, index=True)  # 'created', 'updated', 'revoked', 'renewed', 'schedule_added', etc.
    field_name = Column(String(100))  # Which field changed (NULL for creation)
    old_value = Column(Text)  # Old value as string
    new_value = Column(Text)  # New value as string
    
    # Full state snapshots (for complex changes)
    full_old_state = Column(postgresql.JSONB)  # Complete policy state before
    full_new_state = Column(postgresql.JSONB)  # Complete policy state after
    
    changed_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    
    # Relationships
    policy = relationship("AccessPolicy")
    changed_by = relationship("User", foreign_keys=[changed_by_user_id])


class Stay(Base):
    """Period of Person being inside (may have multiple Sessions)."""
    __tablename__ = "stays"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Core references
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)  # TODO: Rename to person_id in future
    policy_id = Column(Integer, ForeignKey("access_policies.id"), nullable=False, index=True)  # TODO: Rename to grant_id in future
    gate_id = Column(Integer, ForeignKey("gates.id"), nullable=True, index=True)  # Which gate person entered through
    server_id = Column(Integer, ForeignKey("servers.id"), nullable=False, index=True)  # Target server
    
    # Timing
    started_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    ended_at = Column(DateTime, index=True)  # NULL = person still inside
    duration_seconds = Column(Integer)  # Calculated on end
    
    # Status
    is_active = Column(Boolean, default=True, nullable=False, index=True)  # True = person is inside
    termination_reason = Column(String(255))  # grant_expired, revoked, manual_disconnect, schedule_ended
    
    # MFA session persistence - SSH key fingerprint acts as session cookie
    ssh_key_fingerprint = Column(String(255), index=True)  # SHA256 fingerprint for cross-IP session identification
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    # Relationships
    user = relationship("User")  # TODO: Rename to person
    policy = relationship("AccessPolicy")  # TODO: Rename to grant
    gate = relationship("Gate", back_populates="stays")
    server = relationship("Server")
    sessions = relationship("Session", back_populates="stay")  # One stay can have many sessions (disconnect/reconnect)


class Session(Base):
    """Active and historical connection sessions (SSH/RDP)."""
    __tablename__ = "sessions"
    
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String(255), unique=True, nullable=False, index=True)  # Unique session identifier
    
    # Session details
    user_id = Column(Integer, ForeignKey("users.id"), index=True)
    server_id = Column(Integer, ForeignKey("servers.id"), index=True)
    stay_id = Column(Integer, ForeignKey("stays.id"), nullable=True, index=True)  # NEW: Which stay this session belongs to
    gate_id = Column(Integer, ForeignKey("gates.id"), nullable=True, index=True)  # NEW: Which gate handled this session
    protocol = Column(String(10), nullable=False, index=True)  # ssh, rdp
    
    # Connection info
    source_ip = Column(String(45), nullable=False)
    proxy_ip = Column(String(45))  # IP from pool used for this session
    backend_ip = Column(String(45), nullable=False)
    backend_port = Column(Integer, nullable=False)
    ssh_username = Column(String(255))  # SSH login used
    subsystem_name = Column(String(50))  # sftp, scp, etc.
    ssh_agent_used = Column(Boolean, default=False)  # True if SSH agent was used
    
    # Timing
    started_at = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    ended_at = Column(DateTime, index=True)  # NULL = active session
    duration_seconds = Column(Integer)  # Calculated on end
    
    # Recording
    recording_path = Column(String(512))  # Path to session recording file
    recording_size = Column(BigInteger)  # Size in bytes
    
    # Status
    is_active = Column(Boolean, default=True, index=True)
    termination_reason = Column(String(255))  # normal, timeout, error, killed
    
    # Connection attempt tracking (v1.7.5)
    connection_status = Column(String(30), default='active', index=True)  # tcp_connect, handshake, access_granted, denied, backend_connected, active, closed, timeout
    denial_reason = Column(String(100), index=True)  # no_matching_policy, outside_schedule, policy_expired, wrong_source_ip, protocol_not_allowed, ssh_login_not_allowed, etc.
    denial_details = Column(Text)  # Detailed explanation of denial
    protocol_version = Column(String(50))  # SSH-2.0-OpenSSH_8.9, RDP 10.12, etc.
    
    # Audit trail
    policy_id = Column(Integer, ForeignKey("access_policies.id"), index=True)  # Which policy granted access
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    user = relationship("User")
    server = relationship("Server")
    stay = relationship("Stay", back_populates="sessions")  # NEW: Link to stay
    gate = relationship("Gate", back_populates="sessions")  # NEW: Link to gate
    policy = relationship("AccessPolicy")
    transfers = relationship("SessionTransfer", back_populates="session")
    
    __table_args__ = (
        CheckConstraint(
            "protocol IN ('ssh', 'rdp')",
            name="check_session_protocol_valid"
        ),
    )


class MP4ConversionQueue(Base):
    """MP4 conversion queue for RDP session recordings."""
    __tablename__ = "mp4_conversion_queue"
    
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String(255), unique=True, nullable=False, index=True)
    status = Column(String(20), nullable=False, default='pending', index=True)  # pending, converting, completed, failed
    progress = Column(Integer, default=0)  # Current progress count
    total = Column(Integer, default=0)  # Total items to process
    eta_seconds = Column(Integer)  # Estimated time remaining
    priority = Column(Integer, default=0, index=True)  # Higher = processed first
    mp4_path = Column(Text)  # Path to converted MP4 file
    error_msg = Column(Text)  # Error message if failed
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    
    __table_args__ = (
        CheckConstraint("status IN ('pending', 'converting', 'completed', 'failed')", name="check_conversion_status"),
    )


class SessionTransfer(Base):
    """File transfers and port forwarding details for SSH sessions."""
    __tablename__ = "session_transfers"
    
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("sessions.id", ondelete="CASCADE"), nullable=False, index=True)
    
    # Transfer type: 'scp_upload', 'scp_download', 'sftp_upload', 'sftp_download', 
    #                'port_forward_local', 'port_forward_remote', 'socks_connection'
    transfer_type = Column(String(30), nullable=False, index=True)
    
    # For file transfers (SCP/SFTP)
    file_path = Column(Text)  # Remote file path
    file_size = Column(BigInteger)  # Size in bytes
    
    # For port forwarding / SOCKS
    local_addr = Column(String(45))  # Local address
    local_port = Column(Integer)  # Local port
    remote_addr = Column(String(255))  # Remote/destination address
    remote_port = Column(Integer)  # Remote/destination port
    bytes_sent = Column(BigInteger, default=0)  # Bytes sent through tunnel
    bytes_received = Column(BigInteger, default=0)  # Bytes received through tunnel
    
    # Timing
    started_at = Column(DateTime, default=datetime.utcnow, index=True)
    ended_at = Column(DateTime)
    
    # Relationships
    session = relationship("Session", back_populates="transfers")
    
    __table_args__ = (
        CheckConstraint(
            "transfer_type IN ('scp_upload', 'scp_download', 'sftp_upload', 'sftp_download', "
            "'port_forward_local', 'port_forward_remote', 'socks_connection', 'sftp_session')",
            name="check_transfer_type_valid"
        ),
    )


def get_all_user_groups(user_id, db):
    """
    Get all user groups recursively (including parent groups).
    Uses BFS with cycle detection.
    
    Args:
        user_id: User ID
        db: Database session
        
    Returns:
        set: Set of UserGroup IDs
    """
    visited = set()
    queue = []
    
    # Get direct group memberships
    direct_memberships = db.query(UserGroupMember).filter(
        UserGroupMember.user_id == user_id
    ).all()
    
    for membership in direct_memberships:
        queue.append(membership.user_group_id)
    
    # BFS traversal with cycle detection
    while queue:
        group_id = queue.pop(0)
        
        if group_id in visited:
            continue
            
        visited.add(group_id)
        
        # Get parent group
        group = db.query(UserGroup).filter(UserGroup.id == group_id).first()
        if group and group.parent_group_id:
            if group.parent_group_id not in visited:
                queue.append(group.parent_group_id)
    
    return visited


def get_all_server_groups(server_id, db):
    """
    Get all server groups recursively (including parent groups).
    Uses BFS with cycle detection.
    
    Args:
        server_id: Server ID
        db: Database session
        
    Returns:
        set: Set of ServerGroup IDs
    """
    visited = set()
    queue = []
    
    # Get direct group memberships
    direct_memberships = db.query(ServerGroupMember).filter(
        ServerGroupMember.server_id == server_id
    ).all()
    
    for membership in direct_memberships:
        queue.append(membership.group_id)
    
    # BFS traversal with cycle detection
    while queue:
        group_id = queue.pop(0)
        
        if group_id in visited:
            continue
            
        visited.add(group_id)
        
        # Get parent group
        group = db.query(ServerGroup).filter(ServerGroup.id == group_id).first()
        if group and group.parent_group_id:
            if group.parent_group_id not in visited:
                queue.append(group.parent_group_id)
    
    return visited


def validate_no_group_cycle(group_id, new_parent_id, db, model_class):
    """
    Validate that setting parent_group_id won't create a cycle.
    
    Args:
        group_id: Group ID being modified
        new_parent_id: New parent group ID
        db: Database session
        model_class: UserGroup or ServerGroup
        
    Raises:
        ValueError: If cycle detected
    """
    if not new_parent_id:
        return
    
    visited = {group_id}
    current = new_parent_id
    
    while current:
        if current in visited:
            raise ValueError(f"Cycle detected: setting parent would create circular reference")
        
        visited.add(current)
        parent = db.query(model_class).filter(model_class.id == current).first()
        current = parent.parent_group_id if parent else None


def init_db():
    """Initialize database tables."""
    Base.metadata.create_all(bind=engine)
    print("Database tables created successfully!")


def get_db():
    """Get database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


class MFAChallenge(Base):
    """MFA Challenge for SAML authentication."""
    __tablename__ = "mfa_challenges"
    
    id = Column(Integer, primary_key=True, index=True)
    token = Column(String(64), unique=True, nullable=False, index=True)
    gate_id = Column(Integer, ForeignKey("gates.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=True)  # Nullable in Phase 2
    grant_id = Column(Integer, ForeignKey("access_policies.id", ondelete="CASCADE"), nullable=True)  # Nullable in Phase 2
    ssh_username = Column(String(255), nullable=False)
    source_ip = Column(String(45))  # Client source IP
    destination_ip = Column(String(45))  # Phase 2: target server IP for grant lookup after SAML
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)
    verified = Column(Boolean, default=False, nullable=False)
    verified_at = Column(DateTime)
    saml_email = Column(String(255))
    
    # Relationships
    gate = relationship("Gate")
    user = relationship("User")
    grant = relationship("AccessPolicy")


if __name__ == "__main__":
    init_db()
